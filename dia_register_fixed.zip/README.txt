DIA Register - Fixed Project (Codemagic-ready)
----------------------------------------------

This package is prepared to be uploaded to GitHub and built on Codemagic.
Important: Codemagic will run `flutter create . --overwrite` in the detected project folder
to repair Gradle/Android/iOS native folders before building. This avoids the unsupported Gradle error.

Included:
- pubspec.yaml
- lib/main.dart (starter - replace with full app code if you prefer)
- assets/logo.png
- codemagic.yaml (build workflow)
- README.txt (this file)

Usage:
- Upload the contents of this ZIP to your repo (or upload ZIP to Codemagic).
- Ensure codemagic build mode uses repository YAML (codemagic.yaml).
- Trigger build; artifacts will appear under build_outputs.